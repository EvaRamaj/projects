"use strict";

import React from 'react';

import UserForm from './../components/UserForm';

import UserService from '../services/UserService';


export class UserFormView extends React.Component {

    constructor(props) {
        super(props);
    }

    componentWillMount(){
        if(this.props.location.state != undefined && this.props.location.state.user != undefined) {
            this.setState({
                loading: false,
                user: this.props.location.state.user,
                error: undefined
            });
        }
        else {
            this.setState({
                loading: true,
                error: undefined
            });

            UserService.getMyProfile().then((data) => {
                this.setState({
                    user: data,
                    loading: false,
                    error: undefined
                });
            }).catch((e) => {
                console.error(e);
            });
        }
    }

    updateUser(user) {

        UserService.updateUser(user).then((data) => {
            this.props.history.goBack();
        }).catch((e) => {
            console.error(e);
            this.setState(Object.assign({}, this.state, {error: 'Error while creating user'}));
        });

    }

    render() {
        if (this.state.loading) {
            return (<h2>Loading...</h2>);
        }

        return (<UserForm user={this.state.user} onSubmit={(user) => this.updateUser(user)} error={this.state.error} />);
    }
}
