"use strict";

import React from 'react';
import { Card, Button, TextField } from 'react-md';
import { withRouter } from 'react-router-dom';

import { AlertMessage } from './AlertMessage';
import Page from './Page';


const style = { maxWidth: 500 };


class UserSignup extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            username : '',
            password : '',
            email : '',
            first_name : '',
            last_name : '',
            address : '',
            phone : '',
            photo : '',
            id_document : '',
            lesor_role_requested : false,
            role: 'Lessee',
            is_Lessor: false
        };

        this.handleChangeUsername = this.handleChangeUsername.bind(this);
        this.handleChangePassword = this.handleChangePassword.bind(this);
        this.handleChangeEmail = this.handleChangeEmail.bind(this);
        this.handleChangeFirstName = this.handleChangeFirstName.bind(this);
        this.handleChangeLastName = this.handleChangeLastName.bind(this);
        this.handleChangeAddress = this.handleChangeAddress.bind(this);
        this.handleChangePhone = this.handleChangePhone.bind(this);
        this.handleChangePhoto = this.handleChangePhoto.bind(this);
        this.handleChangeIdDocument = this.handleChangeIdDocument.bind(this);
        this.handleChangeLessorRoleRequested = this.handleChangeLessorRoleRequested.bind(this);


        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChangeUsername(value) {
        console.log('username');
        this.setState(Object.assign({}, this.state, {username: value}));
    }
    handleChangePassword(value) {
        console.log('pass');
        this.setState(Object.assign({}, this.state, {password: value}));
    }
    handleChangeEmail(value) {
        console.log('email');
        this.setState(Object.assign({}, this.state, {email: value}));
    }
    handleChangeFirstName(value) {
        this.setState(Object.assign({}, this.state, {first_name: value}));
    }
    handleChangeLastName(value) {
        this.setState(Object.assign({}, this.state, {last_name: value}));
    }
    handleChangeAddress(value) {
        this.setState(Object.assign({}, this.state, {address: value}));
    }
    handleChangePhone(value) {
        this.setState(Object.assign({}, this.state, {phone: value}));
    }
    handleChangePhoto(value) {
        this.setState(Object.assign({}, this.state, {photo: value}));
    }
    handleChangeIdDocument(value) {
        this.setState(Object.assign({}, this.state, {id_document: value}));
    }
    handleChangeLessorRoleRequested(value) {
        this.setState(Object.assign({}, this.state, {lesor_role_requested: value}));
    }

    handleSubmit(event) {
        event.preventDefault();

        let user = {
            username: this.state.username,
            password: this.state.password,
            email: this.state.email,
            first_name : this.state.first_name,
            last_name : this.state.last_name,
            address : this.state.address,
            phone : this.state.phone,
            photo : this.state.photo,
            id_document : this.state.id_document,
            lesor_role_requested : this.state.lesor_role_requested,
            role: this.state.role,
            is_Lessor: this.state.is_Lessor
        };

        this.props.onSubmit(user);
    }

    render() {
        let user = this.state;
        let self = this; // otherwise it doesn't see this obj
        return (
            <Page>
                <Card style={style} className="md-block-centered">
                    <form className="md-grid" onSubmit={this.handleSubmit} onReset={() => this.props.history.goBack()}>

                        {Object.keys(user).map(function(key) {
                            if(key !== 'lesor_role_requested' && key !== 'role' && key !== 'is_Lessor' ){

                                // parse key and process it in order to form handlers name
                                let s = key.toString();
                                let out = s.split("_");
                                let handler = 'handleChange';
                                for (let w in out){
                                    handler += out[w].substring(0, 1).toUpperCase() + out[w].substring(1);
                                }

                                // cases to take into account in order to iterate and display text boxes
                                let label = key;
                                let id = key.toString().toLocaleUpperCase() + 'Field';
                                let required = false;
                                let type = "text";

                                if(key === 'password'){
                                    type = "password";
                                    required = true;
                                }
                                if(key === 'username' || key === 'email'){
                                    required = true;
                                }
                                let value = user.key;
                                let errorText = key.toString() + ' is required!';

                                return <TextField
                                    label={label}
                                    id={id}
                                    type={type}
                                    className="md-row"
                                    required={required}
                                    value={value}
                                    onChange={self[handler]}
                                    errorText={errorText}/>

                            }

                        })}
                        <Button id="submit" type="submit"
                                disabled={this.state.username == undefined || this.state.username == '' || this.state.password == undefined || this.state.password == '' || this.state.email == '' ? true : false}
                                raised primary className="md-cell md-cell--2">Register</Button>
                        <Button id="reset" type="reset" raised secondary className="md-cell md-cell--2">Dismiss</Button>
                        <AlertMessage className="md-row md-full-width" >{this.props.error ? `${this.props.error}` : ''}</AlertMessage>
                    </form>
                </Card>
            </Page>
        );
    }
};

export default withRouter(UserSignup);