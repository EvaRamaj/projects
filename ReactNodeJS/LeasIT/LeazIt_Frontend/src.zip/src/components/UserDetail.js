"use strict";

import React from 'react';
import { Link } from 'react-router-dom'
import { Card, CardTitle, CardText, Media, MediaOverlay, Grid, Cell, Button, FontIcon } from 'react-md';

import Page from './Page';

import AuthService from '../services/AuthService';

export class UserDetail extends React.Component {

    constructor(props) {
        super(props);
        // console.log('UserDetail: ', props);
    }

    render() {
        let user = this.props.user;
        return (
            <Page>
                <Card>
                    <Grid className="grid-example" >
                        <Cell size={3}>
                            <Media aspectRatio="1-1">
                                <img src={`http://localhost:3000/photos/${this.props.user.photo}`} alt={this.props.user.username} />
                            </Media>
                        </Cell>
                        <Cell size={7}/>
                        <Cell size={1}>
                            {AuthService.isAuthenticated() ?
                                <Link to={{pathname: `/edit_profile`, state : {user : this.props.user}}}><Button icon>mode_edit</Button></Link>
                                : <Link to={'/login'}><Button icon>mode_edit</Button></Link>
                            }
                        </Cell>
                        <Cell size={1}>
                            {AuthService.isAuthenticated() ?
                                <Button onClick={() => this.props.onDelete(this.props.user._id)} icon>delete</Button>
                                :   <Link to={'/login'}><Button icon>delete</Button></Link>
                            }
                        </Cell>
                    </Grid>

                    <CardTitle title={this.props.user.username} subtitle={this.props.user.email} />

                    <CardText>
                        {Object.keys(user).map(function(key) {
                            console.log(user);
                            if(key !== '_id' && key !=='__v' && key !=='photo' && key!=='password'){
                                return <div>{key}: {user[key]}</div>
                            }

                        })}
                    </CardText>
                </Card>
            </Page>
        );
    }
}